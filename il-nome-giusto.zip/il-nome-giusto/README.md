# Il Nome Giusto 🌿

> Trova il nome perfetto per il tuo bambino — questionario guidato dall'AI

## Come funziona

1. I genitori rispondono a 8 domande su preferenze di suono, origine, lunghezza e valori
2. L'app manda le risposte all'API di Anthropic (Claude)
3. Vengono suggeriti 5 nomi personalizzati con etimologia, descrizione e compatibilità fonetica

---

## Struttura del progetto

```
il-nome-giusto/
├── src/
│   ├── app/
│   │   ├── layout.tsx          ← Metadata SEO e font
│   │   ├── page.tsx            ← Pagina principale
│   │   ├── globals.css         ← Stili globali e variabili CSS
│   │   └── api/
│   │       └── genera-nomi/
│   │           └── route.ts    ← API route server-side (protegge la chiave API)
│   ├── components/
│   │   ├── NomeApp.tsx         ← Orchestratore principale
│   │   ├── Header.tsx
│   │   ├── QuizStep.tsx        ← Domande del questionario
│   │   ├── LoadingState.tsx
│   │   └── Results.tsx         ← Card con i nomi suggeriti
│   └── lib/
│       ├── questions.ts        ← Dati delle domande (unica fonte di verità)
│       └── types.ts            ← TypeScript types
├── .env.local.example          ← Template variabili d'ambiente
├── vercel.json
└── package.json
```

---

## Setup locale (5 minuti)

### 1. Installa le dipendenze

```bash
npm install
```

### 2. Configura la chiave API

Copia il file di esempio e inserisci la tua chiave:

```bash
cp .env.local.example .env.local
```

Poi apri `.env.local` e sostituisci il valore:

```
ANTHROPIC_API_KEY=sk-ant-la-tua-chiave-qui
```

Ottieni la chiave su: **https://console.anthropic.com/**

### 3. Avvia in locale

```bash
npm run dev
```

Apri **http://localhost:3000** nel browser.

---

## Deploy su Vercel (10 minuti)

### Opzione A — Deploy diretto da GitHub (consigliato)

1. Crea un repo su [github.com](https://github.com) e carica tutti i file
2. Vai su [vercel.com](https://vercel.com) e clicca **"Add New Project"**
3. Importa il repo GitHub
4. Nella sezione **"Environment Variables"**, aggiungi:
   - Nome: `ANTHROPIC_API_KEY`
   - Valore: la tua chiave API
5. Clicca **Deploy**

### Opzione B — Deploy via Vercel CLI

```bash
npm install -g vercel
vercel
```

Poi aggiungi la variabile d'ambiente dalla dashboard Vercel.

### Collegare il dominio ilnomegiusto.it

1. Vai su **Vercel → Settings → Domains**
2. Aggiungi `ilnomegiusto.it` e `www.ilnomegiusto.it`
3. Copia i record DNS che Vercel ti mostra
4. Vai nel pannello del tuo registrar DNS e aggiungi i record
5. Attendi 5–30 minuti per la propagazione

---

## Aggiungere la monetizzazione (prossimi passi)

Il progetto è pronto per essere esteso. Ecco i blocchi successivi:

- **Stripe** — aggiungi `@stripe/stripe-js` e crea una route `/api/checkout` per il pagamento del report premium
- **Report PDF** — usa `@react-pdf/renderer` per generare un PDF scaricabile con tutti i 5 nomi e le loro storie
- **Waitlist** — integra Tally o MailerLite per raccogliere email prima del lancio completo

---

## Costo per utilizzo

Ogni generazione consuma circa 600–800 token in output.
Con Claude Sonnet 4.6 il costo è circa **€0,003–0,005 per richiesta**.
Con un prezzo di vendita di €4,90, il margine è >99%.

---

## Note tecniche

- La chiave API non è mai esposta al browser — passa sempre attraverso la route server `/api/genera-nomi`
- Il progetto usa Next.js 14 App Router
- CSS Modules per lo styling — nessuna dipendenza da Tailwind o altri framework CSS
- TypeScript strict mode attivo
