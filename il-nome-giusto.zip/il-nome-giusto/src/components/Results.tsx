import { NameResult } from '@/lib/types'
import styles from './Results.module.css'

interface Props {
  names: NameResult[]
  onRestart: () => void
}

export default function Results({ names, onRestart }: Props) {
  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h2 className={styles.title}>I nomi più adatti per voi</h2>
        <p className={styles.sub}>Selezionati su misura in base alle vostre preferenze</p>
      </div>

      {names.map((n, i) => (
        <div key={n.name} className={`${styles.nameCard} ${i === 0 ? styles.featured : ''}`}>
          {i === 0 && <div className={styles.badge}>Il più adatto</div>}
          <div className={styles.namePrimary}>{n.name}</div>
          <div className={styles.nameOrigin}>{n.origin}</div>
          <p className={styles.nameDesc}>{n.description}</p>
          {n.tags && n.tags.length > 0 && (
            <div className={styles.tags}>
              {n.tags.map((tag) => (
                <span key={tag} className={styles.tag}>{tag}</span>
              ))}
            </div>
          )}
        </div>
      ))}

      <button className={styles.btnRestart} onClick={onRestart}>
        ↺ Ricomincia con preferenze diverse
      </button>
    </div>
  )
}
